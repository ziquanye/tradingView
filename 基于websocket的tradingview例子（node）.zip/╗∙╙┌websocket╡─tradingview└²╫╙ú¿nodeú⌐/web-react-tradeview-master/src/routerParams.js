

export default [
  {
    path: '/',
    models: () => [],
    page: () => import('./tradeview/TradeviewPage.jsx'),
  },
];
