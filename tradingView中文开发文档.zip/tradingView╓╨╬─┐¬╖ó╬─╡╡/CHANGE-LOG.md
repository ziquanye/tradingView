# 更新日志

## 图表库更新日志
* [版本变更点](book/Breaking-changes.md)

## 1.13 -- 20180419
* 文档更新至Tradingview 1.13 开发库版本

## 1.12 -- 20180113
* 中文开发文档版本与Tradingview开发库版本一致


## 1.1 -- 20171223

* 图片文字汉化
* 链接与内容修正
* 官方wiki同步更新

## 1.0 -- 20170910

* 初版做成


## 0.1 ~ 0.9 -- 20??????

* 膜拜大神

![膜拜](images/muobai.gif)
![zlq4863947](images/zlq4863947.jpg)
<!--stackedit_data:
eyJoaXN0b3J5IjpbMTE0MDI0MDk2MF19
-->